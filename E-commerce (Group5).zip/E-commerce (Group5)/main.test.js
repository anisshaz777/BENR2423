const supertest = require('supertest');
const request = supertest('http://localhost:3000');



describe('Express Route Test', function () {



	it('should return welcome', async () => {

		return request.get('/welcome')

			.expect(200)

			.expect('Content-Type', /text/)

			.then(res => {

				expect(res.text).toBe('Welcome to E-Commerce');

			});

	})



	it('login successfully', async () => {

		return request

			.post('/login')

			.send({ username: 'anis', password: "123456" })

			.expect('Content-Type', /json/)

			.expect(200).then(response => {

				expect(response.body).toEqual(

					expect.objectContaining({

						_id: expect.any(String),

						name: expect.any(String),

						age: expect.any(Number),

					})

				);

			});

	});



	it('login failed', async () => {

		return request

			.post('/login')

			.send({ username: 'anis', password: "mina" })

			.expect('Content-Type', /json/)

			.expect(200).then(response => {

				expect(response.body).toEqual(

					expect.objectContaining({

						_id: expect.any(String),

						name: expect.any(String),

						age: expect.any(Number),

					})

				);

			});

	});

	it('register', async () => {

		return request

			.post('/register')

			.send({ username: 'mina', password: "123" })

			.expect('Content-Type', /json/)

			.expect(200).then(response => {

				expect(response.body).toEqual(

					expect.objectContaining({

						_id: expect.any(String),

						name: expect.any(String),

						age: expect.any(Number),

					})

				);

			});

	});


	it('register failed', async () => {
		return request

			.post('/register')

			.send({ username: 'nani', password: "456" })

			.expect('Content-Type', /json/)

			.expect(200).then(response => {

				expect(response.body).toEqual(

					expect.objectContaining({

						_id: expect.any(String),

						name: expect.any(String),

						age: expect.any(Number),

					})

				);

			});

	});

});